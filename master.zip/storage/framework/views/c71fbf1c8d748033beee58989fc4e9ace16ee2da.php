<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Learn Laravel 5</title>

    <link href="//cdn.bootcss.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet">
    <script src="//cdn.bootcss.com/jquery/1.11.1/jquery.min.js"></script>
    <script src="//cdn.bootcss.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
</head>

    <div id="content" style="padding: 50px;">

        <h4>
            <a href="/"><< 返回首页</a>
        </h4>

        <h1 style="text-align: center; margin-top: 50px;"><?php echo e($article->title); ?></h1>
        <hr>
        <div id="date" style="text-align: right;">
            <?php echo e($article->updated_at); ?>

        </div>
        <div id="content" style="margin: 20px;">
            <p>
                <?php echo e($article->body); ?>

            </p>
        </div>

        <div id="comments" style="margin-top: 50px;">

            <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger">
                    <strong>操作失败</strong> 输入不符合要求<br><br>
                    <?php echo implode('<br>', $errors->all()); ?>

                </div>
            <?php endif; ?>

            <div id="new">
                <form action="<?php echo e(url('comment')); ?>" method="POST">
                    <?php echo csrf_field(); ?>

                    <input type="hidden" name="article_id" value="<?php echo e($article->id); ?>">
                    <div class="form-group">
                        <label>Nickname</label>
                        <input type="text" name="nickname" class="form-control" style="width: 300px;" required="required">
                    </div>
                    <div class="form-group">
                        <label>Email address</label>
                        <input type="email" name="email" class="form-control" style="width: 300px;">
                    </div>
                    <div class="form-group">
                        <label>Home page</label>
                        <input type="text" name="website" class="form-control" style="width: 300px;">
                    </div>
                    <div class="form-group">
                        <label>Content</label>
                        <textarea name="content" id="newFormContent" class="form-control" rows="10" required="required"></textarea>
                    </div>
                    <button type="submit" class="btn btn-lg btn-success col-lg-12">Submit</button>
                </form>
            </div>

            <script>
            function reply(a) {
              var nickname = a.parentNode.parentNode.firstChild.nextSibling.getAttribute('data');
              var textArea = document.getElementById('newFormContent');
              textArea.innerHTML = '@'+nickname+' ';
            }
            </script>

            <div class="conmments" style="margin-top: 100px;">
                <?php $__currentLoopData = $article->hasManyComments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="one" style="border-top: solid 20px #efefef; padding: 5px 20px;">
                        <div class="nickname" data="<?php echo e($comment->nickname); ?>">
                            <?php if($comment->website): ?>
                                <a href="<?php echo e($comment->website); ?>">
                                    <h3><?php echo e($comment->nickname); ?></h3>
                                </a>
                            <?php else: ?>
                                <h3><?php echo e($comment->nickname); ?></h3>
                            <?php endif; ?>
                            <h6><?php echo e($comment->created_at); ?></h6>
                        </div>
                        <div class="content">
                            <p style="padding: 20px;">
                                <?php echo e($comment->content); ?>

                            </p>
                        </div>
                        <div class="reply" style="text-align: right; padding: 5px;">
                            <a href="#new" onclick="reply(this);">回复</a>
                        </div>
                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

    </div>

</body>
</html>