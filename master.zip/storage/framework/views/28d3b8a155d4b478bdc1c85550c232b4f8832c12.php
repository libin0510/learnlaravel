<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">编辑评论</div>
                <div class="panel-body">

                    <?php if(count($errors) > 0): ?>
                        <div class="alert alert-danger">
                            <strong>编辑失败</strong> 输入不符合要求<br><br>
                            <?php echo implode('<br>', $errors->all()); ?>

                        </div>
                    <?php endif; ?>
                    <span><?php echo e($comment->hasOneArticle->title); ?></span>                    
                        <br>
                    <span><?php echo e($comment->nickname); ?></span><span> </span><span><?php echo e($comment->updated_at); ?></span>
                        <br>
                    <form action="<?php echo e(url('admin/comment/'.$comment->id)); ?>" method="post">
                        <?php echo e(method_field('PUT')); ?>

                        <?php echo csrf_field(); ?>                        
                        <textarea name="content" rows="10" class="form-control" required="required"><?php echo e($comment->content); ?></textarea>
                        <br>                        
                        <button class="btn btn-lg btn-info">编辑评论</button>
                    </form>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>