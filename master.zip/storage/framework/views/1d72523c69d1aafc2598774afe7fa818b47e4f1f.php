<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">分类管理</div>
                <div class="panel-body">
                    <?php if(count($errors) > 0): ?>
                        <div class="alert alert-danger">
                            <?php echo implode('<br>', $errors->all()); ?>

                        </div>
                    <?php endif; ?>

                    <table class="table table-bordered">
                      <caption><a href="<?php echo e(url('admin/catetory/create')); ?>" style="float: left" class="btn btn-lg btn-primary">新增</a></caption>
                      <thead>
                        <tr>
                          <th>id</th>
                          <th>名称</th>
                          <th>pid</th>
                          <th>操作</th>
                        </tr>
                      </thead>
                      <tbody>
                      <?php $__currentLoopData = $catetories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $catetory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td><?php echo e($catetory->id); ?></td>
                          <td><?php echo e($catetory->cate_name); ?></td>
                          <td><?php echo e($catetory->pid); ?></td>
                          <td><a href="<?php echo e(url('admin/catetory/'.$catetory->id.'/edit')); ?>" class="btn btn-success">编辑</a>
                        <form action="<?php echo e(url('admin/catetory/'.$catetory->id)); ?>" method="POST" style="display: inline;">
                            <?php echo e(method_field('DELETE')); ?>

                            <?php echo e(csrf_field()); ?>

                            <button type="submit" class="btn btn-danger">删除</button>
                        </form></td>
                        </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                      </tbody>
                    </table>

             </div>
            </div>
         <?php echo e($catetories->render()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>