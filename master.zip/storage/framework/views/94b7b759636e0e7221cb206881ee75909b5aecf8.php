<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">文章管理</div>
                <div class="panel-body">
                    <?php if(count($errors) > 0): ?>
                        <div class="alert alert-danger">
                            <?php echo implode('<br>', $errors->all()); ?>

                        </div>
                    <?php endif; ?>

                    <a href="<?php echo e(url('admin/article/create')); ?>" class="btn btn-lg btn-primary">新增</a>

                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <hr>
                        <div class="article">
                            <h4><?php echo e($article->title); ?></h4>
                            <div class="content">
                                <p>
                                    <?php echo e($article->body); ?>

                                </p>
                            </div>
                        </div>
                        <a href="<?php echo e(url('admin/article/'.$article->id.'/edit')); ?>" class="btn btn-success">编辑</a>
                        <form action="<?php echo e(url('admin/article/'.$article->id)); ?>" method="POST" style="display: inline;">
                            <?php echo e(method_field('DELETE')); ?>

                            <?php echo e(csrf_field()); ?>

                            <button type="submit" class="btn btn-danger">删除</button>
                        </form>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                    
                </div>
            </div>
         <?php echo $data->render(); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>