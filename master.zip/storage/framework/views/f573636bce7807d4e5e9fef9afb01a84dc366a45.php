<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">评论管理</div>
                <div class="panel-body">
                    <?php if(count($errors) > 0): ?>
                        <div class="alert alert-danger">
                            <?php echo implode('<br>', $errors->all()); ?>

                        </div>
                    <?php endif; ?>

                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <hr>
                        <div class="comment">
                            <h4><?php echo e($comment->hasOneArticle->title); ?></h4>
                            <div class="content">
                                <p>
                                    <?php echo e($comment->content); ?>

                                </p>
                            </div>
                        <span><?php echo e($comment->nickname); ?></span><span> 发表于：</span><span><?php echo e($comment->updated_at); ?></span>
                        
                        <div style="Float:right">
                        <a href="<?php echo e(url('admin/comment/'.$comment->id.'/edit')); ?>" class="btn btn-success">编辑</a>
                        <form action="<?php echo e(url('admin/comment/'.$comment->id)); ?>" method="POST" style="display: inline;">
                            <?php echo e(method_field('DELETE')); ?>

                            <?php echo e(csrf_field()); ?>

                            <button type="submit" class="btn btn-danger">删除</button>
                        </form>
                        </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                    
                </div>
            </div>
         <?php echo $data->render(); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>